
public abstract class Background {

	public abstract Tile getTile(int col, int row);
	
	public abstract int getCol(int x);
	
	public abstract int getRow(int y);
	
}
