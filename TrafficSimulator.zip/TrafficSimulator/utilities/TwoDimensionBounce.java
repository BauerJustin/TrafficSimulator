public class TwoDimensionBounce {
	
	protected boolean didBounce = false;
	protected double newVelocityX = 0;
	protected double newVelocityY = 0;
	protected double newX = 0;
	protected double newY = 0;
	protected boolean justBounced = false;

	public TwoDimensionBounce() {		
	}
	
}
