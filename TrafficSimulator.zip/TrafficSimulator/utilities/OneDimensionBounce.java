public class OneDimensionBounce {
	protected double newLocaton = 0;
	protected double newVelocity = 0;
	protected boolean didBounce = false;
}
