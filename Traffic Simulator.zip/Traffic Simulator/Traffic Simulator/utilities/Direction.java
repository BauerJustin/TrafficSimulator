
public enum Direction {
	UP,
	LEFT,
	RIGHT,
	DOWN
}
